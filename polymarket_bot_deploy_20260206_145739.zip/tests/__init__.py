"""
Tests package for Polymarket Trading Bot
"""
